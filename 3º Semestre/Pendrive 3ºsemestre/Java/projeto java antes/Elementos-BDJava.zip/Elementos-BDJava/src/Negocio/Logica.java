package Negocio;


public class Logica {
    private int id;
    private String nome,telefone,nomepet,especie,servic,toza;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNomepet() {
        return nomepet;
    }

    public void setNomepet(String nomepet) {
        this.nomepet = nomepet;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getServic() {
        return servic;
    }

    public void setServic(String servic) {
        this.servic = servic;
    }

    public String getToza() {
        return toza;
    }

    public void setToza(String toza) {
        this.toza = toza;
    }


}
