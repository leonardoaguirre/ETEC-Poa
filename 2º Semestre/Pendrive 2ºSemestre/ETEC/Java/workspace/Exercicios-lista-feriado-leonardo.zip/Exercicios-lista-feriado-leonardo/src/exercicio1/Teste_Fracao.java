package exercicio1;

public class Teste_Fracao {

	public static void main(String[] args) {
		Fracao numerador = new Fracao();
		Fracao denominador = new Fracao();

		
		numerador.setnumerador(15);
		denominador.setdenominador(7);
		numerador.print();

	}

}
