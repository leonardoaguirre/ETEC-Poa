package exercicio1;

public class Teste_Conta {

	public static void main(String[] args) {
		Conta nomeCliente = new Conta();
		Conta saldoConta = new Conta();
		Conta numConta = new Conta();
		
  
		
		nomeCliente.setnomeCliente("leonardo");
		saldoConta.setsaldoConta(14000);
		numConta.setnumConta(105);
		nomeCliente.print();
		
		


		}



	}


