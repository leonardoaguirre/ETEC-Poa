package aula58;

import javax.swing.*;

public class Exercicio1 {

	public static void main(String[] args) {
		Integer resp, A, B, C, respdelta, respdelta2, equa1, equa2;
		resp = Integer.parseInt(JOptionPane.showInputDialog(
				"" + "MENU PRINCIPAL " + " | 1 - Equac�o do 2�: " + " | 2 - Tipo tri�ngulo: " + " | 3 - Sair: "));

		// Equa��o do 2� grau
		if (resp == 1) {
			A = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de A :"));
			B = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de B :"));
			C = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de C :"));
			respdelta = ((B * B) - (4 * A * C));
			respdelta2 = ((B * B) - (4 * A * C));
			if (respdelta >= 0)
				respdelta2 = respdelta;
			equa1 = (int) ((-B + (Math.sqrt(respdelta))) / (2 * A));
			equa2 = (int) ((-B - (Math.sqrt(respdelta2))) / (2 * A));
			JOptionPane.showMessageDialog(null, "Equa��o x1 =" + equa1);
			JOptionPane.showMessageDialog(null, "Equa��o x2 =" + equa2);
		} else {
			JOptionPane.showMessageDialog(null, "A equa��o n�o tem solu��o real");
		}
		// Tri�ngulos
		if (resp == 2) {
			A = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor do lado A :"));
			B = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor do lado B :"));
			C = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor do lado C :"));

			if (((A > B + C) || (B > A + C) || (C > A + B)))

			{

				if (((A == B) && (B == C) && (A == C))) {
					JOptionPane.showMessageDialog(null, "O tri�ngulo � Equil�tero");

				}
				if (((A == B) && (B == C) && (C != A))) {
					JOptionPane.showMessageDialog(null, "O tri�ngulo � Is�sceles");
				}
				if (((A != B) && (B != C) && (C != A))) {
					JOptionPane.showMessageDialog(null, "O tri�ngulo � Escaleno");
				}
			} 
			else 
			{
				JOptionPane.showMessageDialog(null, "Os valores digitados n�o correspondem a um tri�ngulo");
			}
			// Sair
			if (resp == 3);
		}
	}

}
